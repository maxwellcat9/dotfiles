---Collection proxy API documentation
---Messages for controlling and interacting with collection proxies
---which are used to dynamically load collections into the runtime.
---@class collectionproxy
collectionproxy = {}



return collectionproxy