---@meta

---@source UnityEngine.CoreModule.dll
---@class UnityEngine.Scripting.APIUpdating.MovedFromAttribute: System.Attribute
---@source UnityEngine.CoreModule.dll
---@field IsInDifferentAssembly bool
---@source UnityEngine.CoreModule.dll
CS.UnityEngine.Scripting.APIUpdating.MovedFromAttribute = {}
